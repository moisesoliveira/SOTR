# SOTR#

Trabalho final para a disciplina de sistemas operacionais de tempo real
Professor Osmar Marchi dos Santos

https://github.com/moisesoliveira/SOTR
